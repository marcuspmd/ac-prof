"use strict";
// Lógica de Modos de Exibição (Janelas Separadas)
const mode = window.location.hash ? window.location.hash.substring(1) : "full";
document.body.className = `mode-${mode}`;
console.log(`[Overlay] Initialized in mode: ${mode}`);
// Configurações e Variáveis do Veículo (GT3 padrão)
const WHEELBASE = 2.65; // metros (entre-eixos aproximado)
const MAX_STEER_RAD = 0.45; // ~26 graus de esterço máximo da roda dianteira
const SLIP_ANGLE_PEAK = 7.0; // graus (pico de aderência dos pneus)
const G_SCALE = 35; // Pixels por G no canvas
// Histórico para o Diagrama G-G
const ggHistory = [];
const MAX_GG_HISTORY = 40;
// Estado de Coaching e Debounce de Voz
let lastFeedbackTime = 0;
const FEEDBACK_COOLDOWN = 8000; // 8 segundos entre mensagens faladas para reduzir o ruído
const AUDIO_ENABLED = false; // Desabilitar som / fala por enquanto conforme solicitado pelo usuário
// Elementos DOM existentes
const speedIndicator = document.getElementById("speed-indicator");
const gearIndicator = document.getElementById("gear-indicator");
const rpmBar = document.getElementById("rpm-bar");
const throttleBar = document.getElementById("throttle-bar");
const brakeBar = document.getElementById("brake-bar");
const coachMessage = document.getElementById("coach-message");
const coachPanel = document.getElementById("coach-panel");
const nextTurnDisplay = document.getElementById("next-turn-display");
const nextTurnArrow = document.getElementById("next-turn-arrow");
const nextTurnDistance = document.getElementById("next-turn-distance");
const nextTurnTargetSpeed = document.getElementById("next-turn-target-speed");
const nextTurnAction = document.getElementById("next-turn-action");
const nextTurnStatusIndicator = document.getElementById("next-turn-status-indicator");
const colorsPanel = document.getElementById("colors-panel");
const tyreFL = document.getElementById("tyre-fl");
const tyreFR = document.getElementById("tyre-fr");
const tyreRL = document.getElementById("tyre-rl");
const tyreRR = document.getElementById("tyre-rr");
// --- NOVOS ELEMENTOS DOM E VARIÁVEIS PARA RECURSOS AVANÇADOS ---
const trackPosTarget = document.getElementById("track-pos-target");
const trackPosCar = document.getElementById("track-pos-car");
const traceCanvas = document.getElementById("trace-canvas");
const traceCtx = traceCanvas ? traceCanvas.getContext("2d") : null;
const scorecardOverlay = document.getElementById("scorecard-overlay");
const scorecardGrade = document.getElementById("scorecard-grade");
const scorecardApexSpeed = document.getElementById("scorecard-apex-speed");
const scorecardTrailScore = document.getElementById("scorecard-trail-score");
const scorecardApexTiming = document.getElementById("scorecard-apex-timing");
const scorecardGripUtil = document.getElementById("scorecard-grip-util");
// Estado de rastreamento de curva
let hasAnnouncedCurrentTurn = false;
let hasAnnouncedBrakingPoint = false;
let lastNextTurnDist = -1;
let lastNextTurnAngle = 0;
// Capacidades de aceleração dinâmicas
let maxObservedLatG = 1.4; // Capacidade G lateral máxima padrão (se auto-calibra com a telemetria)
let maxObservedDecelG = 1.0; // Desaceleração de frenagem máxima padrão (se auto-calibra com a telemetria)
let maxObservedAccelG = 0.5; // Aceleração de tração máxima padrão
const inputHistory = [];
const MAX_INPUT_HISTORY = 120; // 120 frames a 60Hz (~2 segundos)
// Variáveis de curva para o scorecard
let inCorner = false;
let cornerSamples = [];
let currentCornerStartDist = -1;
let currentCornerAngle = 0;
// Setup Canvas G-G
const canvas = document.getElementById("gg-canvas");
const ctx = canvas.getContext("2d");
function initGGCanvas(currentAccX = 0, currentAccZ = 0) {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    const cx = canvas.width / 2;
    const cy = canvas.height / 2;
    // Desenhar círculos de referência (1G, 1.5G)
    ctx.strokeStyle = "rgba(255, 255, 255, 0.1)";
    ctx.lineWidth = 1;
    // 1G Circle
    ctx.beginPath();
    ctx.arc(cx, cy, 1.0 * G_SCALE, 0, 2 * Math.PI);
    ctx.stroke();
    // 1.5G Circle
    ctx.beginPath();
    ctx.arc(cx, cy, 1.5 * G_SCALE, 0, 2 * Math.PI);
    ctx.stroke();
    // Eixos Cruzados
    ctx.strokeStyle = "rgba(255, 255, 255, 0.05)";
    ctx.beginPath();
    ctx.moveTo(0, cy);
    ctx.lineTo(canvas.width, cy);
    ctx.moveTo(cx, 0);
    ctx.lineTo(cx, canvas.height);
    ctx.stroke();
    // --- Desenhar Envelope de Grip Máximo da Sessão (Elipse pontilhada) ---
    ctx.strokeStyle = "rgba(239, 68, 68, 0.22)";
    ctx.lineWidth = 1.2;
    ctx.setLineDash([2, 3]);
    const rx = maxObservedLatG * G_SCALE;
    const ryAccel = maxObservedAccelG * G_SCALE;
    const ryDecel = maxObservedDecelG * G_SCALE;
    // Superior (Aceleração, Z negativo)
    ctx.beginPath();
    ctx.ellipse(cx, cy, rx, ryAccel, 0, Math.PI, 2 * Math.PI);
    ctx.stroke();
    // Inferior (Frenagem, Z positivo)
    ctx.beginPath();
    ctx.ellipse(cx, cy, rx, ryDecel, 0, 0, Math.PI);
    ctx.stroke();
    ctx.setLineDash([]); // Reset das linhas
    // Escrever uso de G instantâneo no canto inferior esquerdo
    ctx.fillStyle = "rgba(255, 255, 255, 0.35)";
    ctx.font = "8px 'Outfit', sans-serif";
    ctx.textAlign = "left";
    const currentTotalG = Math.sqrt(currentAccX * currentAccX + currentAccZ * currentAccZ);
    const maxPossibleG = currentAccZ < 0
        ? Math.sqrt(maxObservedLatG * maxObservedLatG + maxObservedAccelG * maxObservedAccelG)
        : Math.sqrt(maxObservedLatG * maxObservedLatG + maxObservedDecelG * maxObservedDecelG);
    const utilization = Math.min(100, Math.round((currentTotalG / Math.max(0.1, maxPossibleG)) * 100));
    ctx.fillText(`USO: ${utilization}%`, 6, canvas.height - 6);
}
function updateGGDiagram(accX, accZ) {
    const cx = canvas.width / 2;
    const cy = canvas.height / 2;
    // Inverter o X porque forças G laterais são opostas ao sentido físico de curva
    const px = cx - accX * G_SCALE;
    const py = cy + accZ * G_SCALE; // accZ negativo é aceleração, positivo é frenagem
    // Adiciona ao histórico
    ggHistory.push({ x: px, y: py });
    if (ggHistory.length > MAX_GG_HISTORY) {
        ggHistory.shift();
    }
    // Redesenha a base com os valores instantâneos passados para computar uso %
    initGGCanvas(accX, accZ);
    // Desenha o rastro histórico (fading)
    for (let i = 0; i < ggHistory.length; i++) {
        const pt = ggHistory[i];
        const alpha = (i / ggHistory.length) * 0.4;
        ctx.fillStyle = `rgba(59, 130, 246, ${alpha})`;
        ctx.beginPath();
        ctx.arc(pt.x, pt.y, 2, 0, 2 * Math.PI);
        ctx.fill();
    }
    // Desenha o ponto atual em destaque
    ctx.fillStyle = "#60a5fa";
    ctx.shadowColor = "#3b82f6";
    ctx.shadowBlur = 8;
    ctx.beginPath();
    ctx.arc(px, py, 5, 0, 2 * Math.PI);
    ctx.fill();
    ctx.shadowBlur = 0; // Reset
}
// Atualização de Cores dos Pneus baseados em Slip Angle
function setTyreVisual(element, slipAngle) {
    const absSlip = Math.abs(slipAngle);
    element.className = "tyre-indicator";
    if (absSlip > SLIP_ANGLE_PEAK * 1.4) {
        element.classList.add("tyre-slip-high");
    }
    else if (absSlip > SLIP_ANGLE_PEAK * 0.9) {
        element.classList.add("tyre-slip-mid");
    }
    else if (absSlip > 1.5) {
        element.classList.add("tyre-slip-low");
    }
}
// Envia feedback de áudio via Text-To-Speech (SpeechSynthesis) com opção de silenciamento de fala
function speakFeedback(message, type, speak = true) {
    const now = Date.now();
    if (speak && AUDIO_ENABLED && (now - lastFeedbackTime < FEEDBACK_COOLDOWN))
        return false;
    // Define as classes visuais do painel do coach
    coachPanel.className = "";
    if (type === "warning")
        coachPanel.classList.add("coach-warning");
    else if (type === "danger")
        coachPanel.classList.add("coach-danger");
    else if (type === "success")
        coachPanel.classList.add("coach-success");
    else
        coachPanel.className = "coach-neutral";
    coachMessage.innerText = message;
    // Utiliza a Web Speech API para dar voz ao Engenheiro de Corrida apenas se solicitado e áudio habilitado
    if (speak && AUDIO_ENABLED && 'speechSynthesis' in window) {
        window.speechSynthesis.cancel(); // Cancela áudios pendentes
        const utterance = new SpeechSynthesisUtterance(message);
        utterance.lang = "pt-BR";
        utterance.rate = 1.0;
        utterance.pitch = 0.9;
        window.speechSynthesis.speak(utterance);
        lastFeedbackTime = now;
    }
    return true;
}
// Motor de Análise Física (Heurísticas)
function analyzePhysics(data) {
    const speed = data.speedMs;
    const steer = data.steer; // -1 a 1
    const yawRate = data.yawRate; // rad/s
    const brake = data.brake;
    const throttle = data.throttle;
    // Ângulo de esterço nas rodas em radianos
    const steerRad = steer * MAX_STEER_RAD;
    // Slip angles dos pneus em graus
    const slipFL = data.tyres[0].slipAngle;
    const slipFR = data.tyres[1].slipAngle;
    const slipRL = data.tyres[2].slipAngle;
    const slipRR = data.tyres[3].slipAngle;
    const avgFrontSlip = (Math.abs(slipFL) + Math.abs(slipFR)) / 2;
    const avgRearSlip = (Math.abs(slipRL) + Math.abs(slipRR)) / 2;
    // 1. Heurística de Entrada Excessiva (Velocidade)
    if (speed > 15 && avgFrontSlip > SLIP_ANGLE_PEAK * 1.3 && brake > 0.1) {
        speakFeedback("Entrada rápida demais! Alivie a pressão no freio para recuperar aderência.", "danger");
        return;
    }
    // 2. Heurística de Understeer (Subesterço)
    if (speed > 8 && Math.abs(steer) > 0.15) {
        // Cálculo do Yaw Esperado (Ackermann)
        const expectedYawRaw = (speed * steerRad) / WHEELBASE;
        // Cap físico do Yaw rate dinâmico baseado na aceleração lateral máxima aproximada (~1.35G)
        const maxPhysicalYaw = (1.35 * 9.81 * Math.max(0.1, data.roadGrip)) / Math.max(speed, 1.0);
        const expectedYaw = Math.min(Math.abs(expectedYawRaw), maxPhysicalYaw) * Math.sign(steerRad);
        const yawDelta = Math.abs(expectedYaw) - Math.abs(yawRate);
        // Se o carro vira menos do que deveria, os pneus dianteiros estão deslizando além do pico,
        // e o escorregamento dianteiro é superior ao traseiro (para evitar falsos positivos de sobresterço/tração)
        if (yawDelta > 0.15 && avgFrontSlip > SLIP_ANGLE_PEAK * 1.2 && avgFrontSlip > avgRearSlip) {
            speakFeedback("Subesterço! Reduza o ângulo de esterço.", "warning");
            return;
        }
    }
    // 3. Heurística de Oversteer (Sobresterço / Traseira Escorregando)
    if (Math.abs(yawRate) > 0.15 && speed > 10) {
        // Contra-esterço: esterçando no sentido contrário da guinada
        const counterSteer = Math.sign(steer) !== Math.sign(yawRate);
        if (counterSteer && avgRearSlip > SLIP_ANGLE_PEAK * 1.2) {
            speakFeedback("Sobresterço! Mantenha o contra-esterço controlado.", "danger");
            return;
        }
    }
    // 4. Heurística de Trail Braking
    if (brake > 0.05 && Math.abs(steer) > 0.2) {
        if (brake > 0.6) {
            speakFeedback("Sobrecarga de frenagem! Alivie o freio na entrada da curva.", "warning", false); // Apenas visual
            return;
        }
        else if (brake < 0.2 && brake > 0.05) {
            speakFeedback("Belo Trail Braking. Segure o nariz do carro até o ápice.", "success", false); // Apenas visual
            return;
        }
    }
    // 5. Heurística de Aceleração Precoce
    if (throttle > 0.5 && Math.abs(steer) > 0.3 && speed < 30) {
        if (avgRearSlip > SLIP_ANGLE_PEAK * 0.8) {
            speakFeedback("Patinando na tração! Suavize a aplicação de aceleração.", "warning");
            return;
        }
    }
    // 6. Detecção de Travamento de Rodas (Lockup)
    const slipRatioFL = data.tyres[0].slipRatio;
    const slipRatioFR = data.tyres[1].slipRatio;
    const slipRatioRL = data.tyres[2].slipRatio;
    const slipRatioRR = data.tyres[3].slipRatio;
    if (brake > 0.15) {
        if (slipRatioFL < -0.22 || slipRatioFR < -0.22) {
            speakFeedback("Travando rodas dianteiras! Alivie o freio para não passar reto.", "danger", false);
            return;
        }
        if (slipRatioRL < -0.22 || slipRatioRR < -0.22) {
            speakFeedback("Travando rodas traseiras! Risco de rodar, alivie o freio.", "danger", false);
            return;
        }
    }
    // Feedback padrão
    if (speed > 5) {
        coachMessage.innerText = "Pilotagem limpa. Mantenha os olhos nos pontos de frenagem.";
        coachPanel.className = "coach-neutral";
    }
}
console.log("[Overlay] app.js loaded successfully!");
// Lógica de Atualização Visual e por Voz da Próxima Curva
function updateUpcomingTurn(data) {
    const dist = data.nextTurnDist;
    const angle = data.nextTurnAngle;
    // Se a distância for inválida ou menor/igual a zero, mostra valores neutros (sem ocultar o widget)
    if (dist <= 0) {
        nextTurnDistance.innerText = "--m";
        nextTurnArrow.innerText = "↩️";
        nextTurnDisplay.className = "panel-glass";
        nextTurnStatusIndicator.className = "status-neutral";
        nextTurnTargetSpeed.innerText = "Ideal: -- km/h";
        nextTurnAction.innerText = "MANTENHA VELOCIDADE";
        if (colorsPanel)
            colorsPanel.className = "state-neutral";
        hasAnnouncedCurrentTurn = false;
        hasAnnouncedBrakingPoint = false;
        lastNextTurnDist = dist;
        lastNextTurnAngle = angle;
        return;
    }
    // Detecta transição para uma nova curva
    const distIncreased = dist > lastNextTurnDist + 50;
    const angleChanged = Math.abs(angle - lastNextTurnAngle) > 20;
    if (distIncreased || angleChanged) {
        hasAnnouncedCurrentTurn = false;
        hasAnnouncedBrakingPoint = false;
    }
    lastNextTurnDist = dist;
    lastNextTurnAngle = angle;
    // Atualiza o widget visual com a distância
    nextTurnDistance.innerText = `${Math.round(dist)}m`;
    // Direção da curva (corrigido: positivo = direita, negativo = esquerda)
    const isRight = angle > 0;
    if (isRight) {
        nextTurnArrow.innerText = "➡️";
    }
    else {
        nextTurnArrow.innerText = "⬅️";
    }
    // --- LÓGICA DE VELOCIDADE DE ENTRADA (Cálculo Físico-Dinâmico) ---
    const speed = data.speedMs; // velocidade atual em m/s
    const absAngle = Math.abs(angle);
    // Estimativa contínua e realista da velocidade ideal (km/h) baseada na angulação da curva
    // Usamos a fórmula baseada no limite físico de contorno de curva
    let baseTargetKmh = 800 / Math.sqrt(Math.max(1.0, absAngle));
    // Limita os extremos de velocidade alvo para curvas muito abertas ou fechadas
    baseTargetKmh = Math.max(50, Math.min(290, baseTargetKmh));
    // Multiplicadores físicos:
    // 1. Grip da pista (velocidade proporcional à raiz do grip)
    const gripFactor = Math.sqrt(Math.max(0.1, data.roadGrip));
    // 2. Capacidade dinâmica do veículo (calculada com base no G lateral máximo observado com cap de segurança de 1.25x)
    const carPerformanceFactor = Math.min(1.25, Math.sqrt(maxObservedLatG / 1.4));
    let vTargetKmh = baseTargetKmh * gripFactor * carPerformanceFactor;
    // 3. Penalidade por posicionamento incorreto de entrada na curva (aplica-se apenas perto da curva < 60m)
    const pLat = data.trackPosLat; // -1.0 = esquerda, 1.0 = direita
    const wrongSideFactor = isRight ? pLat : -pLat;
    if (dist < 60 && wrongSideFactor > 0) {
        const proximityScale = (60 - dist) / 60;
        vTargetKmh = vTargetKmh * (1.0 - 0.2 * wrongSideFactor * proximityScale);
    }
    // Velocidade alvo convertida para m/s para os cálculos de física
    const vTarget = vTargetKmh / 3.6;
    // Atualiza a velocidade ideal na placa
    nextTurnTargetSpeed.innerText = `Ideal: ${Math.round(vTargetKmh)} km/h`;
    // --- CÁLCULO PREVENTIVO E PREDITIVO DE DISTÂNCIA DE FRENAGEM ---
    // Deceleração alvo planejada: 80% da capacidade máxima de desaceleração (20% de margem de segurança / "gordurinha")
    const targetDecelMs2 = maxObservedDecelG * 9.81 * 0.80 * Math.max(0.5, data.roadGrip);
    // Distância percorrida durante o tempo de reação do piloto (~0.3 segundos)
    const reactionTime = 0.3; // segundos
    const reactionDistance = speed * reactionTime;
    // Distância física de frenagem para desacelerar de speed para vTarget (v^2 = u^2 + 2ad => d = (v^2 - u^2)/2a)
    let physicalBrakingDistance = 0;
    if (speed > vTarget) {
        physicalBrakingDistance = (speed * speed - vTarget * vTarget) / (2 * targetDecelMs2);
    }
    // Distância total de frenagem preventiva necessária (reação + frenagem física)
    const totalBrakingDistanceNeeded = physicalBrakingDistance + reactionDistance;
    // Desaceleração requerida instantânea (sem margem) para monitoramento
    let aReq = 0;
    if (speed > vTarget) {
        aReq = (speed * speed - vTarget * vTarget) / (2 * Math.max(1.0, dist));
    }
    // Deceleração real do veículo estimada
    const aActual = Math.max(0, -data.accG.z * 9.81);
    const isBraking = data.brake > 0.15;
    const isBrakingSufficiently = isBraking && (data.brake > 0.4 || aActual >= aReq - 1.5);
    // Detecção de travamento de rodas (Lockup) na placa
    let frontLocked = false;
    let rearLocked = false;
    if (data.brake > 0.15) {
        if (data.tyres[0].slipRatio < -0.22 || data.tyres[1].slipRatio < -0.22) {
            frontLocked = true;
        }
        if (data.tyres[2].slipRatio < -0.22 || data.tyres[3].slipRatio < -0.22) {
            rearLocked = true;
        }
    }
    // Define os estilos visuais de acordo com o status
    if (speed > 10.0 && speed < vTarget - 5.0 && dist < 100) {
        // Se o piloto reduziu a velocidade excessivamente (mais de 18 km/h abaixo da velocidade alvo)
        nextTurnDisplay.className = "panel-glass next-turn-safe";
        nextTurnStatusIndicator.className = "status-safe";
        nextTurnAction.innerText = "ACELERE!";
        if (colorsPanel)
            colorsPanel.className = "state-safe";
    }
    else if (dist > totalBrakingDistanceNeeded + 25) {
        // Velocidade segura
        nextTurnDisplay.className = "panel-glass next-turn-safe";
        nextTurnStatusIndicator.className = "status-safe";
        nextTurnAction.innerText = "VELOCIDADE OK";
        if (colorsPanel)
            colorsPanel.className = "state-safe";
    }
    else if (dist > totalBrakingDistanceNeeded) {
        // Velocidade limítrofe (atenção, zona de aproximação)
        nextTurnDisplay.className = "panel-glass next-turn-warning";
        nextTurnStatusIndicator.className = "status-warning";
        nextTurnAction.innerText = "PREPARE-SE";
        if (colorsPanel)
            colorsPanel.className = "state-warning";
    }
    else {
        // Zona de frenagem necessária
        if (frontLocked) {
            nextTurnDisplay.className = "panel-glass next-turn-danger";
            nextTurnStatusIndicator.className = "status-danger";
            nextTurnAction.innerText = "TRAVANDO FRENTE!";
            if (colorsPanel)
                colorsPanel.className = "state-danger";
        }
        else if (rearLocked) {
            nextTurnDisplay.className = "panel-glass next-turn-danger";
            nextTurnStatusIndicator.className = "status-danger";
            nextTurnAction.innerText = "TRAVANDO TRASEIRA!";
            if (colorsPanel)
                colorsPanel.className = "state-danger";
        }
        else if (isBrakingSufficiently) {
            // Piloto já está freando o suficiente
            nextTurnDisplay.className = "panel-glass next-turn-braking";
            nextTurnStatusIndicator.className = "status-braking";
            nextTurnAction.innerText = "FRENAGEM OK";
            if (colorsPanel)
                colorsPanel.className = "state-braking";
        }
        else {
            // Rápido demais, precisa começar a frear
            nextTurnDisplay.className = "panel-glass next-turn-danger";
            nextTurnStatusIndicator.className = "status-danger";
            nextTurnAction.innerText = "FREIE AGORA!";
            if (colorsPanel)
                colorsPanel.className = "state-danger";
            // Alerta sonoro apenas no momento de entrar na zona de perigo de frenagem (1x por curva)
            if (!hasAnnouncedBrakingPoint) {
                if (speakFeedback("Freie!", "danger")) {
                    hasAnnouncedBrakingPoint = true;
                }
            }
        }
    }
}
let updateCount = 0;
// Ponto de Entrada da Telemetria (Chamado a partir do CSP Lua)
window.onTelemetryUpdate = function (data) {
    if (!data) {
        console.warn("[Overlay] Received empty telemetry data");
        return;
    }
    updateCount++;
    // Atualiza a capacidade lateral G máxima observada do veículo (limitado a 2.0G para evitar picos de batidas)
    const currentLatG = Math.abs(data.accG.x);
    if (currentLatG > maxObservedLatG && currentLatG < 2.0) {
        maxObservedLatG = currentLatG;
    }
    // Atualiza a desaceleração de frenagem máxima observada (limitado a 1.6G)
    const currentDecelG = -data.accG.z;
    if (currentDecelG > maxObservedDecelG && currentDecelG < 1.6 && data.brake > 0.8) {
        maxObservedDecelG = currentDecelG;
    }
    // Atualiza a aceleração de tração máxima observada (limitado a 1.0G)
    const currentAccelG = data.accG.z;
    if (currentAccelG > maxObservedAccelG && currentAccelG < 1.0 && data.throttle > 0.8) {
        maxObservedAccelG = currentAccelG;
    }
    if (updateCount % 60 === 1) {
        console.log(`[Overlay] Telemetry update #${updateCount} received. Speed: ${data.speedKmh.toFixed(1)} km/h, Gear: ${data.gear}, RPM: ${Math.round(data.engineRPM)}`);
    }
    // Atualizar Velocidade e Marcha
    speedIndicator.innerText = Math.round(data.speedKmh).toString();
    const gear = data.gear;
    if (gear === -1)
        gearIndicator.innerText = "R";
    else if (gear === 0)
        gearIndicator.innerText = "N";
    else
        gearIndicator.innerText = gear.toString();
    // Acelerador e Freio
    throttleBar.style.width = `${Math.min(data.throttle * 100, 100)}%`;
    brakeBar.style.width = `${Math.min(data.brake * 100, 100)}%`;
    // Barra de RPM
    const rpmPercent = (data.engineRPM / 8500) * 100;
    rpmBar.style.width = `${Math.min(rpmPercent, 100)}%`;
    // Visual do Pneus (FL: 0, FR: 1, RL: 2, RR: 3)
    setTyreVisual(tyreFL, data.tyres[0].slipAngle);
    setTyreVisual(tyreFR, data.tyres[1].slipAngle);
    setTyreVisual(tyreRL, data.tyres[2].slipAngle);
    setTyreVisual(tyreRR, data.tyres[3].slipAngle);
    // G-G Diagram
    updateGGDiagram(data.accG.x, data.accG.z);
    // Atualizar widget e coaching da próxima curva
    updateUpcomingTurn(data);
    // Executar análises e feedback
    analyzePhysics(data);
    // --- NOVAS ATUALIZAÇÕES DOS RECURSOS AVANÇADOS ---
    // 1. Gráfico Rolante de Inputs (Trace Canvas)
    drawInputsTrace(data.throttle, data.brake, data.steer);
    // 2. Barra de Posicionamento e Alvo de Curva
    updateTrackPositionWidget(data);
    // 3. Monitoramento de Excesso de Esterço (Tyre Scrub)
    checkSteeringScrub(data);
    // 4. Acumulador de Telemetria de Curva para o Scorecard
    const dist = data.nextTurnDist;
    const angle = data.nextTurnAngle;
    if (dist > 0 && dist < 80) {
        if (!inCorner) {
            inCorner = true;
            cornerSamples = [];
            currentCornerStartDist = dist;
            currentCornerAngle = angle;
        }
        cornerSamples.push({
            speedMs: data.speedMs,
            roadGrip: data.roadGrip,
            accG: { x: data.accG.x, z: data.accG.z },
            brake: data.brake,
            steer: data.steer,
            trackPosLat: data.trackPosLat
        });
    }
    else if (inCorner && (dist <= 0 || dist > currentCornerStartDist + 50)) {
        inCorner = false;
        processCornerStats();
    }
};
// --- FUNÇÕES DE RENDERIZAÇÃO E PROCESSAMENTO DOS RECURSOS AVANÇADOS ---
// 1. Desenhar o Gráfico Rolante de Inputs (Trace)
function drawInputsTrace(throttle, brake, steer) {
    if (!traceCanvas || !traceCtx)
        return;
    // Armazena no buffer
    inputHistory.push({ throttle, brake, steer });
    if (inputHistory.length > MAX_INPUT_HISTORY) {
        inputHistory.shift();
    }
    traceCtx.clearRect(0, 0, traceCanvas.width, traceCanvas.height);
    const w = traceCanvas.width;
    const h = traceCanvas.height;
    // Linha central do volante (cinza escuro)
    traceCtx.strokeStyle = "rgba(255, 255, 255, 0.08)";
    traceCtx.lineWidth = 1;
    traceCtx.beginPath();
    traceCtx.moveTo(0, h / 2);
    traceCtx.lineTo(w, h / 2);
    traceCtx.stroke();
    // Desenhar steer (ângulo de volante, azul-elétrico)
    traceCtx.strokeStyle = "rgba(59, 130, 246, 0.7)";
    traceCtx.lineWidth = 1.2;
    traceCtx.beginPath();
    for (let i = 0; i < inputHistory.length; i++) {
        const x = (i / MAX_INPUT_HISTORY) * w;
        const val = inputHistory[i].steer; // -1.0 a 1.0
        const y = h / 2 + (val * (h / 2 - 3));
        if (i === 0)
            traceCtx.moveTo(x, y);
        else
            traceCtx.lineTo(x, y);
    }
    traceCtx.stroke();
    // Desenhar freio (vermelho)
    traceCtx.strokeStyle = "rgba(239, 68, 68, 0.85)";
    traceCtx.lineWidth = 1.5;
    traceCtx.beginPath();
    for (let i = 0; i < inputHistory.length; i++) {
        const x = (i / MAX_INPUT_HISTORY) * w;
        const val = inputHistory[i].brake; // 0.0 a 1.0
        const y = h - (val * (h - 6)) - 3;
        if (i === 0)
            traceCtx.moveTo(x, y);
        else
            traceCtx.lineTo(x, y);
    }
    traceCtx.stroke();
    // Desenhar acelerador (verde)
    traceCtx.strokeStyle = "rgba(16, 185, 129, 0.85)";
    traceCtx.lineWidth = 1.5;
    traceCtx.beginPath();
    for (let i = 0; i < inputHistory.length; i++) {
        const x = (i / MAX_INPUT_HISTORY) * w;
        const val = inputHistory[i].throttle; // 0.0 a 1.0
        const y = h - (val * (h - 6)) - 3;
        if (i === 0)
            traceCtx.moveTo(x, y);
        else
            traceCtx.lineTo(x, y);
    }
    traceCtx.stroke();
}
// 2. Atualizar a Barra de Posicionamento e Alvo de Curva
function updateTrackPositionWidget(data) {
    if (!trackPosTarget || !trackPosCar)
        return;
    const dist = data.nextTurnDist;
    const angle = data.nextTurnAngle;
    const currentPos = data.trackPosLat; // -1 a 1
    // Atualizar a bolinha do carro (azul)
    const carLeftPct = ((currentPos + 1) / 2) * 100;
    trackPosCar.style.left = `${Math.max(2, Math.min(98, carLeftPct))}%`;
    // Calcular alvo ideal baseado no traçado de pista recomendado
    let targetPos = 0; // centro
    if (dist > 0 && dist < 90) {
        const isRight = angle > 0;
        const apexSide = isRight ? 0.85 : -0.85; // Dentro
        const outsideSide = isRight ? -0.9 : 0.9; // Fora (abrir)
        if (dist > 50) {
            targetPos = outsideSide; // Preparação: abrir a curva
        }
        else if (dist > 15) {
            const ratio = (dist - 15) / 35; // 0 a 1 (transição progressiva)
            targetPos = apexSide + (outsideSide - apexSide) * ratio;
        }
        else {
            targetPos = apexSide; // Tangência: buscar o ápice
        }
    }
    else if (inCorner && cornerSamples.length > 0) {
        const isRight = currentCornerAngle > 0;
        targetPos = isRight ? -0.8 : 0.8; // Saída de curva: abrir a trajetória
    }
    // Atualizar o marcador verde de alvo ideal
    const targetLeftPct = ((targetPos + 1) / 2) * 100;
    trackPosTarget.style.left = `${Math.max(2, Math.min(98, targetLeftPct))}%`;
}
// 3. Monitoramento de Excesso de Esterço (Steering Scrub)
function checkSteeringScrub(data) {
    const speed = data.speedMs;
    const slipFL = data.tyres[0].slipAngle;
    const slipFR = data.tyres[1].slipAngle;
    const avgFrontSlip = (Math.abs(slipFL) + Math.abs(slipFR)) / 2;
    const flEl = document.getElementById("tyre-fl");
    const frEl = document.getElementById("tyre-fr");
    if (flEl && frEl) {
        flEl.classList.remove("tyre-scrub");
        frEl.classList.remove("tyre-scrub");
        // Se o escorregamento dos pneus frontais exceder a aderência ideal de forma drástica (> 30%)
        if (speed > 4.5 && avgFrontSlip > SLIP_ANGLE_PEAK * 1.3 && Math.abs(data.steer) > 0.22) {
            flEl.classList.add("tyre-scrub");
            frEl.classList.add("tyre-scrub");
        }
    }
}
// 4. Processar e Exibir o Painel de Performance Pós-Curva (Scorecard)
let scorecardTimeout = null;
function processCornerStats() {
    if (cornerSamples.length < 5)
        return;
    const speedKmhList = cornerSamples.map(s => s.speedMs * 3.6);
    const minSpeedKmh = Math.min(...speedKmhList);
    // Velocidade ideal calculada
    let baseTargetKmh = 800 / Math.sqrt(Math.max(1.0, Math.abs(currentCornerAngle)));
    baseTargetKmh = Math.max(50, Math.min(290, baseTargetKmh));
    const gripFactor = Math.sqrt(Math.max(0.1, cornerSamples[0].roadGrip));
    const carPerformanceFactor = Math.min(1.25, Math.sqrt(maxObservedLatG / 1.4));
    const targetKmh = baseTargetKmh * gripFactor * carPerformanceFactor;
    // Nota de velocidade
    const speedDiff = minSpeedKmh - targetKmh;
    let speedScore = 100;
    if (speedDiff < 0) {
        speedScore = Math.max(0, 100 - Math.abs(speedDiff) * 4.5);
    }
    else {
        speedScore = Math.max(0, 100 - Math.abs(speedDiff) * 2.5); // penaliza menos passar rápido, pois indica agressividade
    }
    // Nota de Trail Braking
    let trailBrakingSamples = 0;
    let perfectTrailSamples = 0;
    let highBrakeSteerSamples = 0;
    let earlyRelease = true;
    cornerSamples.forEach(s => {
        if (Math.abs(s.steer) > 0.15) {
            if (s.brake > 0.05) {
                earlyRelease = false;
                trailBrakingSamples++;
                if (s.brake <= 0.3) {
                    perfectTrailSamples++;
                }
                else {
                    highBrakeSteerSamples++;
                }
            }
        }
    });
    let trailScore = 0;
    if (earlyRelease) {
        trailScore = 35; // Soltou o freio cedo demais
    }
    else if (trailBrakingSamples > 0) {
        const perfectRatio = perfectTrailSamples / trailBrakingSamples;
        const highBrakeRatio = highBrakeSteerSamples / trailBrakingSamples;
        trailScore = Math.round(50 + 55 * perfectRatio - 35 * highBrakeRatio);
        trailScore = Math.max(0, Math.min(100, trailScore));
    }
    else {
        trailScore = 100; // Curvas rápidas de pé embaixo
    }
    // Classificação do Apex Timing
    let apexTimingText = "Ideal";
    const minSpeedIndex = cornerSamples.findIndex(s => s.speedMs * 3.6 === minSpeedKmh);
    const pct = minSpeedIndex / cornerSamples.length;
    const insideDirection = currentCornerAngle > 0 ? 1 : -1;
    const maxInsideDev = Math.max(...cornerSamples.map(s => s.trackPosLat * insideDirection));
    if (maxInsideDev < 0.45) {
        apexTimingText = "Longe do Ápice";
    }
    else if (pct < 0.28) {
        apexTimingText = "Ápice Cedo";
    }
    else if (pct > 0.72) {
        apexTimingText = "Ápice Atrasado";
    }
    else {
        apexTimingText = "Perfeito";
    }
    // Uso de Grip
    let totalEff = 0;
    cornerSamples.forEach(s => {
        const g = Math.sqrt(s.accG.x * s.accG.x + s.accG.z * s.accG.z);
        const eff = g / maxObservedLatG;
        totalEff += eff;
    });
    const avgGripUtil = Math.round((totalEff / cornerSamples.length) * 100);
    const finalGripUtil = Math.min(100, Math.max(0, avgGripUtil));
    // Computa a nota final (S, A+, A, B, C, D)
    const gripScore = Math.min(100, (finalGripUtil / 85) * 100);
    const finalScore = Math.round((speedScore * 0.4) + (trailScore * 0.3) + (gripScore * 0.3));
    let grade = "C";
    let gradeClass = "grade-blue";
    if (finalScore >= 95) {
        grade = "S";
        gradeClass = "grade-gold";
    }
    else if (finalScore >= 88) {
        grade = "A+";
        gradeClass = "grade-green";
    }
    else if (finalScore >= 80) {
        grade = "A";
        gradeClass = "grade-green";
    }
    else if (finalScore >= 70) {
        grade = "B";
        gradeClass = "grade-blue";
    }
    else if (finalScore >= 60) {
        grade = "C";
        gradeClass = "grade-blue";
    }
    else {
        grade = "D";
        gradeClass = "grade-red";
    }
    // Exibir na UI do overlay
    if (scorecardOverlay && scorecardGrade) {
        scorecardGrade.innerText = grade;
        scorecardGrade.className = gradeClass;
        scorecardApexSpeed.innerText = `${Math.round(minSpeedKmh)} km/h (Ideal: ${Math.round(targetKmh)})`;
        scorecardTrailScore.innerText = `${Math.round(trailScore)}%`;
        scorecardApexTiming.innerText = apexTimingText;
        scorecardGripUtil.innerText = `${Math.round(finalGripUtil)}%`;
        scorecardOverlay.classList.remove("scorecard-hidden");
        if (scorecardTimeout)
            clearTimeout(scorecardTimeout);
        scorecardTimeout = setTimeout(() => {
            scorecardOverlay.classList.add("scorecard-hidden");
        }, 4500); // Fica exibido por 4.5 segundos
    }
}
// 5. Motor de Simulação Integrada (Mock Telemetry para testes em navegadores comuns)
function startMockSimulation() {
    console.log("[Overlay] Iniciando Simulador de Telemetria Integrado...");
    let mockDistance = 0;
    let mockSpeedMs = 60; // ~216 km/h
    let mockSteer = 0;
    let mockThrottle = 1.0;
    let mockBrake = 0.0;
    let mockGear = 5;
    let mockRPM = 6000;
    setInterval(() => {
        // Avança distância fictícia ao longo da volta
        mockDistance += mockSpeedMs * 0.0167;
        if (mockDistance > 800) {
            mockDistance = 0;
            mockSpeedMs = 50;
            mockGear = 4;
        }
        let nextTurnDist = -1;
        let nextTurnAngle = 65; // Curva à direita de 65 graus
        let trackPosLat = 0.0;
        let accX = 0;
        let accZ = 0;
        const tyres = [
            { slipAngle: 0, slipRatio: 0, load: 5000, ndSlip: 0 },
            { slipAngle: 0, slipRatio: 0, load: 5000, ndSlip: 0 },
            { slipAngle: 0, slipRatio: 0, load: 4000, ndSlip: 0 },
            { slipAngle: 0, slipRatio: 0, load: 4000, ndSlip: 0 }
        ];
        if (mockDistance < 250) {
            // Reta principal
            mockThrottle = 1.0;
            mockBrake = 0.0;
            mockSteer = 0.0;
            mockSpeedMs += 0.35;
            if (mockSpeedMs > 66)
                mockSpeedMs = 66; // 238 km/h max
            mockGear = 5;
            mockRPM = 4000 + (mockSpeedMs - 50) * 150;
            trackPosLat = -0.6; // Aberto à esquerda esperando a curva
            accZ = -0.3; // G de aceleração
        }
        else if (mockDistance >= 250 && mockDistance < 370) {
            // Aproximação e Zona de Frenagem
            nextTurnDist = 370 - mockDistance;
            trackPosLat = -0.88; // Abre totalmente a curva
            if (nextTurnDist > 65) {
                mockThrottle = 1.0;
                mockBrake = 0.0;
                accZ = -0.1;
            }
            else if (nextTurnDist > 15) {
                // Frenagem forte & Início de Curva (Trail braking)
                mockThrottle = 0.0;
                const brakeProgress = (nextTurnDist - 15) / 50; // 1 a 0
                mockBrake = 0.15 + brakeProgress * 0.75; // Alivia progressivamente
                // Esterço entra conforme freio alivia (trail)
                mockSteer = (1 - brakeProgress) * 0.44;
                mockSpeedMs -= 0.65;
                if (mockSpeedMs < 24)
                    mockSpeedMs = 24; // 86 km/h
                mockGear = 3;
                mockRPM = 5200 - (65 - nextTurnDist) * 35;
                accZ = mockBrake * 1.1; // Desaceleração G
                accX = mockSteer * 2.4; // Lateral G
                tyres[0].slipAngle = -mockSteer * 14;
                tyres[1].slipAngle = -mockSteer * 12;
                tyres[0].slipRatio = -mockBrake * 0.15;
            }
            else {
                // Ápice da curva (baixo freio, esterço alto, tangência máxima)
                mockThrottle = 0.15;
                mockBrake = 0.08;
                mockSteer = 0.49;
                mockSpeedMs = 23.5;
                mockRPM = 4600;
                mockGear = 2;
                trackPosLat = 0.82; // Toca a zebra de dentro
                accX = 1.39; // Lateral G no limite
                accZ = 0.08;
                // Simula oversteer/steering scrub no pneu dianteiro interno
                tyres[0].slipAngle = -9.6; // Força Scrub (> peak * 1.3)
                tyres[1].slipAngle = -8.2;
            }
        }
        else if (mockDistance >= 370 && mockDistance < 500) {
            // Saída da curva acelerando e abrindo
            nextTurnDist = -1;
            const exitProgress = Math.min(1, (mockDistance - 370) / 130);
            mockThrottle = 0.3 + exitProgress * 0.7;
            mockBrake = 0.0;
            mockSteer = 0.49 * (1 - exitProgress);
            mockSpeedMs += 0.28;
            mockGear = 3;
            mockRPM = 4200 + exitProgress * 1800;
            trackPosLat = 0.82 - exitProgress * 1.62; // Abre para o lado de fora
            accX = 1.39 * (1 - exitProgress);
            accZ = -mockThrottle * 0.45;
            tyres[0].slipAngle = -mockSteer * 6;
            tyres[1].slipAngle = -mockSteer * 5;
        }
        else {
            // Reta posterior
            mockThrottle = 1.0;
            mockBrake = 0.0;
            mockSteer = 0.0;
            mockSpeedMs += 0.35;
            mockGear = 4;
            mockRPM = 4800 + (mockSpeedMs - 40) * 80;
            trackPosLat = -0.8;
            accZ = -0.3;
        }
        const mockData = {
            speedMs: mockSpeedMs,
            speedKmh: mockSpeedMs * 3.6,
            gear: mockGear,
            engineRPM: mockRPM,
            steer: mockSteer,
            throttle: mockThrottle,
            brake: mockBrake,
            clutch: 0,
            yaw: 0,
            yawRate: mockSteer * (mockSpeedMs / 30),
            accG: { x: accX, y: 0.0, z: -accZ },
            tyres: tyres,
            nextTurnDist: nextTurnDist,
            nextTurnAngle: nextTurnAngle,
            roadGrip: 1.0,
            trackPosLat: trackPosLat
        };
        window.onTelemetryUpdate(mockData);
    }, 16.7);
}
// Inicialização
initGGCanvas();
// Verifica se deve rodar no modo simulação/mock
if (window.location.search.includes("mock=true")) {
    startMockSimulation();
}
