local telemetry = require('telemetry')
local WebBrowser = require('shared/web/browser')

local function log(msg)
  ac.log("[Race Coach Overlay] " .. tostring(msg))
end

-- Instâncias dos navegadores para cada janela
local browserHud = nil
local browserNextTurn = nil
local browserGG = nil
local browserColors = nil

-- Rastreadores de tamanho para evitar redimensionamento a cada frame (flicker)
local trackerHud = { x = 0, y = 0 }
local trackerNextTurn = { x = 0, y = 0 }
local trackerGG = { x = 0, y = 0 }
local trackerColors = { x = 0, y = 0 }

-- Função auxiliar para inicializar um navegador CEF
local function createBrowser(hash, defaultSize)
  local acRoot = ac.getFolder(ac.FolderID.Root):gsub("\\", "/")
  local htmlUrl = "file:///" .. acRoot .. "/apps/lua/race-coach-overlay/overlay/index.html" .. hash
  htmlUrl = htmlUrl:gsub(" ", "%%20")
  
  log("Initializing browser for " .. hash .. " with URL: " .. htmlUrl)
  
  local success, res = pcall(function()
    return WebBrowser({
      url = htmlUrl,
      size = defaultSize,
      backgroundColor = rgbm(0, 0, 0, 0), -- Transparente
      redirectAudio = false
    })
    :onLoadStart(function(b)
      log("Browser load start: " .. tostring(b:url()))
    end)
    :onLoadEnd(function(b)
      local currentUrl = b:url()
      log("Browser load end: " .. tostring(currentUrl))
      if currentUrl == "" or currentUrl:startsWith("about:blank") then
        b:navigate(htmlUrl)
      end
    end)
    :onLoadError(function(b, data)
      log(string.format("Browser load error: failedURL=%s, errorCode=%s, errorText=%s", tostring(data.failedURL), tostring(data.errorCode), tostring(data.errorText)))
    end)
    :navigate(htmlUrl)
  end)
  
  if success and res then
    return res
  else
    log("Failed to create browser for " .. hash .. ": " .. tostring(res))
    return nil
  end
end

-- Função auxiliar para desenhar o browser e enviar a telemetria
local function updateAndDraw(browserInstance, tracker)
  if not browserInstance then return end

  -- Desenha o componente WebBrowser preenchendo a janela do app usando ImGui
  local size = ui.availableSpace()
  ui.dummy(size)
  local r1, r2 = ui.itemRect()
  
  -- Redimensiona o navegador apenas se o tamanho mudou
  if size.x ~= tracker.x or size.y ~= tracker.y then
    tracker.x = size.x
    tracker.y = size.y
    browserInstance:resize(size)
  end
  browserInstance:draw(r1, r2, false)

  -- Envia os dados de telemetria
  local telemetrySuccess, data = pcall(telemetry.getTelemetry, 0)
  if telemetrySuccess and data then
    local jsonSuccess, jsonStr = pcall(JSON.stringify, data)
    if jsonSuccess and jsonStr then
      browserInstance:execute(string.format("if (window.onTelemetryUpdate) window.onTelemetryUpdate(%s);", jsonStr))
    end
  end
end

-- Janela principal: HUD (Velocidade, Marcha, Pedais, Pneus, Engenheiro)
function windowMain(dt)
  if not browserHud then
    browserHud = createBrowser("#hud", vec2(350, 180))
  end
  updateAndDraw(browserHud, trackerHud)
end

-- Janela secundária: Placa da Próxima Curva
function windowNextTurn(dt)
  if not browserNextTurn then
    browserNextTurn = createBrowser("#next-turn", vec2(140, 110))
  end
  updateAndDraw(browserNextTurn, trackerNextTurn)
end

-- Janela terciária: Diagrama G-G
function windowGG(dt)
  if not browserGG then
    browserGG = createBrowser("#gg", vec2(160, 180))
  end
  updateAndDraw(browserGG, trackerGG)
end

-- Janela quaternária: Semáforo de Cores (Frenagem periférica)
function windowColors(dt)
  if not browserColors then
    browserColors = createBrowser("#colors", vec2(80, 80))
  end
  updateAndDraw(browserColors, trackerColors)
end

-- ==========================================================================
-- PROJEÇÃO 3D HOLOGRÁFICA NA PISTA (TRACKPAINT)
-- ==========================================================================

local trackPainter = ac.TrackPaint()
local maxObservedLatG = 1.4
local maxObservedDecelG = 1.0
local maxObservedAccelG = 0.5

function script.update(dt)
  local car = ac.getCar(0)
  if not car then return end

  -- 1. Auto-calibração de forças G
  local accX = math.abs(car.acceleration.x)
  if accX > maxObservedLatG and accX < 2.0 then
    maxObservedLatG = accX
  end

  local decelG = -car.acceleration.z
  if decelG > maxObservedDecelG and decelG < 1.8 and car.brake > 0.5 then
    maxObservedDecelG = decelG
  end

  local accelG = car.acceleration.z
  if accelG > maxObservedAccelG and accelG < 1.0 and car.gas > 0.8 then
    maxObservedAccelG = accelG
  end

  -- 2. Obter dados da próxima curva
  local upcomingTurn = ac.getTrackUpcomingTurn(0)
  local nextTurnDist = -1
  local nextTurnAngle = 0
  if upcomingTurn then
    nextTurnDist = upcomingTurn.x
    nextTurnAngle = upcomingTurn.y
  end

  -- 3. Calcular a velocidade ideal da curva e a distância de frenagem
  local sim = ac.getSim()
  local roadGrip = sim and sim.roadGrip or 1.0
  local trackLength = sim and sim.trackLengthM or 1.0

  local vTarget = 0
  local totalBrakingDistanceNeeded = 0

  if nextTurnDist > 0 then
    local absAngle = math.abs(nextTurnAngle)
    local baseTargetKmh = 800 / math.sqrt(math.max(1.0, absAngle))
    baseTargetKmh = math.max(50, math.min(290, baseTargetKmh))

    local gripFactor = math.sqrt(math.max(0.1, roadGrip))
    local carPerformanceFactor = math.min(1.25, math.sqrt(maxObservedLatG / 1.4))
    local vTargetKmh = baseTargetKmh * gripFactor * carPerformanceFactor
    vTarget = vTargetKmh / 3.6

    local targetDecel = maxObservedDecelG * 9.81 * 0.80 * math.max(0.5, roadGrip)
    local reactionDistance = car.speedMs * 0.3

    local physicalBrakingDistance = 0
    if car.speedMs > vTarget then
      physicalBrakingDistance = (car.speedMs * car.speedMs - vTarget * vTarget) / (2 * targetDecel)
    end
    totalBrakingDistanceNeeded = physicalBrakingDistance + reactionDistance
  end

  -- 4. Limpar o desenho anterior
  trackPainter:reset()

  -- 5. Desenhar o traçado à frente (80 metros amostrados a cada 2 metros)
  local currentSegmentColor = nil
  local stepSizeMeters = 2
  local totalDistMeters = 80

  for d = 0, totalDistMeters, stepSizeMeters do
    local p = car.splinePosition + d / trackLength
    if p > 1.0 then p = p - 1.0 end
    local worldPos = ac.trackProgressToWorldCoordinate(p, true)

    -- Determina a cor com base na distância de frenagem
    local color = rgbm(0, 0.7, 1, 0.4) -- Azul claro por padrão (reta)

    if nextTurnDist > 0 then
      local distToCorner = nextTurnDist - d
      if distToCorner > 0 then
        if distToCorner < totalBrakingDistanceNeeded then
          if car.speedMs > vTarget + 2 then
            color = rgbm(1, 0, 0, 0.6) -- Vermelho (frenagem necessária)
          else
            color = rgbm(0, 1, 0, 0.5) -- Verde (velocidade ideal atingida)
          end
        elseif distToCorner < totalBrakingDistanceNeeded + 15 then
          color = rgbm(1, 0.7, 0, 0.6) -- Laranja (preparação)
        else
          color = rgbm(0, 1, 0, 0.5) -- Verde (velocidade segura de aproximação)
        end
      else
        -- Dentro/após o ápice da curva
        color = rgbm(0, 0.8, 1, 0.5) -- Azul
      end
    end

    -- Desenhar o segmento
    if currentSegmentColor == nil then
      currentSegmentColor = color
      trackPainter:to(worldPos)
    elseif color ~= currentSegmentColor then
      trackPainter:to(worldPos)
      trackPainter:stroke(false, currentSegmentColor, 0.5)
      currentSegmentColor = color
      trackPainter:to(worldPos)
    else
      trackPainter:to(worldPos)
    end
  end
  if currentSegmentColor then
    trackPainter:stroke(false, currentSegmentColor, 0.5)
  end

  -- 6. Desenhar círculo no ápice físico da curva
  if nextTurnDist > 0 and nextTurnDist < 100 then
    local apexProgress = car.splinePosition + nextTurnDist / trackLength
    if apexProgress > 1.0 then apexProgress = apexProgress - 1.0 end
    local apexWorldPos = ac.trackProgressToWorldCoordinate(apexProgress, true)

    local apexColor = rgbm(1, 0.8, 0, 0.8) -- Dourado/Amarelo
    if nextTurnDist < 15 then
      apexColor = rgbm(0, 1, 0, 0.8) -- Verde quando passar pelo ápice
    end
    trackPainter:circle(apexWorldPos, 1.2, false, apexColor)
  end
end
